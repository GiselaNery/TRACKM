from email.mime.text import MIMEText
from flask import Flask, request, jsonify
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import cv2  # Para reconhecimento facial
import os

app = Flask(__name__)

@app.route('/enviar-relatorio', methods=['POST'])
def enviar_relatorio():
    nome_aluno = request.form['nomeAluno']
    imagem_entrada = request.files['imagemEntrada']
    imagem_saida = request.files['imagemSaida']

    # Salvar imagens
    imagem_entrada.save(os.path.join('uploads', imagem_entrada.filename))
    imagem_saida.save(os.path.join('uploads', imagem_saida.filename))

    # Enviar e-mail
    enviar_email(nome_aluno, imagem_entrada.filename, imagem_saida.filename)

    return jsonify({"status": "Relatório enviado com sucesso!"})

def enviar_email(nome_aluno, imagem_entrada, imagem_saida):
    from_email = 'seu_email@gmail.com'
    to_email = 'destinatario@gmail.com'
    subject = f'Relatório de {nome_aluno}'
    body = 'Veja os anexos para as imagens de entrada e saída.'

    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))

    for filename in [imagem_entrada, imagem_saida]:
        attachment = open(os.path.join('uploads', filename), 'rb')
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename= {filename}')
        msg.attach(part)

    with smtplib.SMTP('smtp.gmail.com', 587) as server:
        server.starttls()
        server.login(from_email, 'sua_senha')
        server.send_message(msg)

    print("E-mail enviado!")

if __name__ == '__main__':
    app.run(debug=True)
    