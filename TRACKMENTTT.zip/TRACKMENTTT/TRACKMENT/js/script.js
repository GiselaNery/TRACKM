function validarFormulario() {
    const denuncia = document.getElementById('denuncia').value;
    if (denuncia.trim() === '') {
        alert('Por favor, descreva a sua denúncia.');
        return false;
    }
    
    return true;
}



function leiaMais(id) {
    var conteudo = document.getElementById(id);
    if (conteudo.style.display === "none") {
        conteudo.style.display = "block";
        botao.innerHTML = "Leia Menos"; // Altera o texto do botão
    } else {
        conteudo.style.display = "none";
        botao.innerHTML = "Saiba Mais"; // Retorna o texto do botão
    }
}



