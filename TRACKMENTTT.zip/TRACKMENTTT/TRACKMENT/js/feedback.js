const feedbacks = [
    "Juliana Silva: Top!!!",
    "Kiane Gurgel: Este é um ótimo site!",
    "Lucas Henrique: A experiência do usuário é fantástica.",
    "Gisela Nery: Adorei o design e a usabilidade.",
    "Herverton Monteiro: Muito fácil de navegar e encontrar informações.",
    "Leandro Barros: Recomendo a todos!",
    "Julio Cesar: Plataforma incrível e muito útil.",
    "Thyago Mendeiros: Atendimento rápido e eficiente.",
    "Gustavo Souza: Interface amigável e intuitiva.",
    "Igor Matheus: Achei tudo o que precisava com facilidade.",
    "Vitoria Hadassa: Site seguro e confiável.",
    "Eduarda Matias: Adorei a iniciativa e a execução.",
    "Marileide Maria: Fácil de usar e muito informativo.",
   
];

let currentFeedbackIndex = 0;
const feedbackText = document.getElementById("feedback-text");
const userCommentInput = document.getElementById("user-comment");
const submitCommentButton = document.getElementById("submit-comment");

// Função para mostrar o próximo feedback
function showNextFeedback() {
    feedbackText.textContent = feedbacks[currentFeedbackIndex];
    currentFeedbackIndex = (currentFeedbackIndex + 1) % feedbacks.length;
}

// Define o tempo de transição do feedback (em milissegundos)
setInterval(showNextFeedback, 3000);

// Adiciona um evento no botão de envio do feedback
submitCommentButton.addEventListener("click", function() {
    const newFeedback = userCommentInput.value.trim();
    
    if (newFeedback) {
        feedbacks.push(newFeedback); // Adiciona o novo feedback à lista
        userCommentInput.value = ''; // Limpa o campo de entrada
        // Opcional: Atualiza para mostrar o novo feedback imediatamente
        currentFeedbackIndex = (currentFeedbackIndex - 1 + feedbacks.length) % feedbacks.length; // Ajusta o índice para mostrar o feedback mais recente
        showNextFeedback(); // Exibe o feedback mais recente
    } else {
        alert("Por favor, insira um comentário!"); // Mensagem de alerta se o campo estiver vazio
    }
});

// Exibe o primeiro feedback imediatamente
showNextFeedback();
