
let nomeAluno = '';
let fotoEntradaUrl = '';
let fotoSaidaUrl = '';

document.getElementById('iniciarMonitoramento').addEventListener('click', function() {
    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');
    const constraints = {
        video: true
    };

    navigator.mediaDevices.getUserMedia(constraints)
        .then(function(stream) {
            video.srcObject = stream;
            video.play();
            document.getElementById('monitoramentoInfo').style.display = 'block';

            // Captura o nome do aluno
            nomeAluno = prompt("Gisela Nery:"); // Adicionando prompt para nome
        })
        .catch(function(error) {
            console.error("Erro ao acessar a câmera: ", error);
        });
});

document.getElementById('registrarEntrada').addEventListener('click', function() {
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');
    const horaEntrada = new Date().toLocaleTimeString();
    document.getElementById('nomeEntrada').innerText = nomeAluno;
    document.getElementById('horaEntrada').innerText = horaEntrada;

    // Captura a imagem do vídeo para entrada
    context.drawImage(document.getElementById('video'), 0, 0, canvas.width, canvas.height);
    fotoEntradaUrl = canvas.toDataURL();
    document.getElementById('foto').src = fotoEntradaUrl;

    // Envia a foto da entrada pelo WhatsApp
    const mensagemEntrada = `Registro de Entrada:\nNome: ${nomeAluno}\nHora: ${horaEntrada}\nFoto: ${fotoEntradaUrl}`;
    const urlWhatsAppEntrada = `https://web.whatsapp.com/send?&text=${encodeURIComponent(mensagemEntrada)}`;
    window.open(urlWhatsAppEntrada, '_blank');
});

document.getElementById('registrarSaida').addEventListener('click', function() {
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');
    const horaSaida = new Date().toLocaleTimeString();
    document.getElementById('nomeSaida').innerText = nomeAluno;
    document.getElementById('horaSaida').innerText = horaSaida;

    // Captura a imagem do vídeo para saída
    context.drawImage(document.getElementById('video'), 0, 0, canvas.width, canvas.height);
    fotoSaidaUrl = canvas.toDataURL();

    // Envia a foto de saída pelo WhatsApp
    const mensagemSaida = `Registro de Saída:\nNome: ${nomeAluno}\nHora: ${horaSaida}\nFoto: ${fotoSaidaUrl}`;
    const urlWhatsAppSaida = `https://web.whatsapp.com/send?&text=${encodeURIComponent(mensagemSaida)}`;
    window.open(urlWhatsAppSaida, '_blank');
});

document.getElementById('retornar').addEventListener('click', function() {
    const horaRetorno = new Date().toLocaleTimeString();
    document.getElementById('nomeRetorno').innerText = nomeAluno;
    document.getElementById('horaRetorno').innerText = horaRetorno;
});

